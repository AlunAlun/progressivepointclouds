//
//  PCA.h
//  PointCloudsGL
//
//  Created by Alun on 10/06/14.
//  Copyright (c) 2014 Alun. All rights reserved.
//

#ifndef __PointCloudsGL__PCA__
#define __PointCloudsGL__PCA__

#include <iostream>
#include <vector>
#include <math.h>
#include "glm.hpp"
#include "Eigen/Dense"

using namespace std;
using namespace glm;

class PCA {
public:
    static vector<vec3> GetEigenVectors(vector<vec3> points);
};

#endif /* defined(__PointCloudsGL__PCA__) */
