//
//  PCA.cpp
//  PointCloudsGL
//
//  Created by Alun on 10/06/14.
//  Copyright (c) 2014 Alun. All rights reserved.
//
/*
#include "PCA.h"

using Eigen::Matrix3f;

vec3 mean(vector<vec3> points) {
    float xSum = 0, ySum = 0, zSum = 0;
    
    int pointsSize = (int)points.size();
    for (int i = 0; i < pointsSize; i++) {
        xSum += points[i].x;
        ySum += points[i].y;
        zSum += points[i].z;
    }
    vec3 means(xSum / pointsSize, ySum / pointsSize, zSum / pointsSize);

    return means;
}

vector<vec3> PCA::GetEigenVectors(vector<vec3> points) {
    
    float sumXX = 0, sumXY = 0, sumXZ = 0,
          sumYX = 0, sumYY = 0, sumYZ = 0,
          sumZX = 0, sumZY = 0, sumZZ = 0;
    vec3 p;
    vec3 m = mean(points);
    for (int i = 0; i < points.size(); i++) {
        //substract mean
        p = vec3(points[i].x-m.x, points[i].y-m.y, points[i].z-m.z) ;
        
        sumXX += (p.x)*(p.x);
        sumXY += (p.x)*(p.y);
        sumXZ += (p.x)*(p.z);
        
        sumYX += (p.y)*(p.x);
        sumYY += (p.y)*(p.y);
        sumYZ += (p.y)*(p.z);
        
        sumZX += (p.z)*(p.x);
        sumZY += (p.z)*(p.y);
        sumZZ += (p.z)*(p.z);

    }
    int ps = (int)points.size();
    float covXX = sumXX/ps;
    float covXY = sumXY/ps;
    float covXZ = sumXZ/ps;
    
    float covYX = sumYX/ps;
    float covYY = sumYY/ps;
    float covYZ = sumYZ/ps;
    
    float covZX = sumZX/ps;
    float covZY = sumZY/ps;
    float covZZ = sumZZ/ps;

    
    Matrix3f A;
    A << covXX, covXY, covXZ,
         covYX, covYY, covYZ,
         covZX, covZY, covZZ;
    Eigen::SelfAdjointEigenSolver<Matrix3f> eigensolver(A);
    if (eigensolver.info() != Eigen::Success) {printf("error calculating eigenvectors\n");}
//    cout << "The eigenvalues of A are:\n" << eigensolver.eigenvalues() << endl;
//    cout << "Here's a matrix whose columns are eigenvectors of A \n"
//         << "corresponding to these eigenvalues:\n"
//         << eigensolver.eigenvectors() << endl;
    Matrix3f r = eigensolver.eigenvectors();
    
    vector<vec3> toReturn;
    toReturn.push_back(vec3(r(0,0),r(1,0),r(2,0)));
    toReturn.push_back(vec3(r(0,1),r(1,1),r(2,1)));
    toReturn.push_back(vec3(r(0,2),r(1,2),r(2,2)));
    return toReturn;
    

}
*/